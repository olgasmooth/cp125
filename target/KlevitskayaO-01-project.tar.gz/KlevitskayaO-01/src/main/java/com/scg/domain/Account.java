/**
 * 
 */
package com.scg.domain;

/**
 * @author olgas
 *
 */

public interface Account {
		
	public String getName();
	public boolean isBillable();

}
