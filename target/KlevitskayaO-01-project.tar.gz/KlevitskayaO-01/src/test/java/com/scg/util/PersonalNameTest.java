///**
// * 
// */
//package com.scg.util;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
///**
// * @author olgas
// *
// */
//class PersonalNameTest {
//
//	/**
//	 * @throws java.lang.Exception
//	 */
//	@BeforeAll
//	static void setUpBeforeClass() throws Exception {
//	}
//
//	/**
//	 * @throws java.lang.Exception
//	 */
//	@BeforeEach
//	void setUp() throws Exception {
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#hashCode()}.
//	 */
//	@Test
//	final void testHashCode() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#PersonalName()}.
//	 */
//	@Test
//	final void testPersonalName() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#PersonalName(java.lang.String, java.lang.String)}.
//	 */
//	@Test
//	final void testPersonalNameStringString() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#PersonalName(java.lang.String, java.lang.String, java.lang.String)}.
//	 */
//	@Test
//	final void testPersonalNameStringStringString() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#getFirstName()}.
//	 */
//	@Test
//	final void testGetFirstName() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#getLastName()}.
//	 */
//	@Test
//	final void testGetLastName() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#getMiddleName()}.
//	 */
//	@Test
//	final void testGetMiddleName() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#setFirstName(java.lang.String)}.
//	 */
//	@Test
//	final void testSetFirstName() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#setLastName(java.lang.String)}.
//	 */
//	@Test
//	final void testSetLastName() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#setMiddleName(java.lang.String)}.
//	 */
//	@Test
//	final void testSetMiddleName() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#toString()}.
//	 */
//	@Test
//	final void testToString() {
//		fail("Not yet implemented"); // TODO
//	}
//
//	/**
//	 * Test method for {@link com.scg.util.PersonalName#equals(java.lang.Object)}.
//	 */
//	@Test
//	final void testEqualsObject() {
//		fail("Not yet implemented"); // TODO
//	}
//
//}
